﻿using System.Collections.Generic;

namespace AuditoriasCiudadanas.Models
{
    public class ModelTemaCapacitacion

    {
        public List<itemTemaCap> TemaCapacitacion { get; set; }

    }
}