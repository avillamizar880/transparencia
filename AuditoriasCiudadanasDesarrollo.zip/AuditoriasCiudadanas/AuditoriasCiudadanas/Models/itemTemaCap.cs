﻿namespace AuditoriasCiudadanas.Models
{
    public class itemTemaCap
    {
        public int idCap { get; set; }
        public string TituloCapacitacion { get; set; }
        public string DetalleCapacitacion { get; set; }
        public string Activo { get; set; }
    }
}