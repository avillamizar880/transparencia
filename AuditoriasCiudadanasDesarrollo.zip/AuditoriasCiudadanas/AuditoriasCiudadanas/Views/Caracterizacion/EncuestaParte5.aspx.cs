﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AuditoriasCiudadanas.Views.Caracterizacion
{
  public partial class EncuestaParte5 : App_Code.PageSession
    {
    protected void Page_Load(object sender, EventArgs e)
    {

    }
  }
}