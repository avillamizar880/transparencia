﻿using System;

namespace AuditoriasCiudadanas.Views.AccesoInformacion
{
  public partial class BuscadorProyectosAuditores : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
    }
  }
}