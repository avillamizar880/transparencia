﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AuditoriasCiudadanas.Controllers
{
    public class clsCorreos
    {
        public string correoFechaReuPrevias() {
            string outTxt = "";

            return outTxt;
        }
    }
}