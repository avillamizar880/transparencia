﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AuditoriasCiudadanas.Models
{
    public class itemReturn
    {
        public string cod_error { get; set; }
        public string msg_error { get; set; }

        public int id { get; set; }
    }
}