﻿using System.Web.UI;

namespace AuditoriasCiudadanas.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}